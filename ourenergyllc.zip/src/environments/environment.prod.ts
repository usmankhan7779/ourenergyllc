export const environment = {
  production: true,
  // url: 'https://apis.wattcrm.com/',
  url:'https://devbackend.wattcrm.com/',
  webenrollurl: 'https://webenrollapi.smartixai.com/',
  backendurl: 'https://backend.wattcrm.com/',
  agenturl: 'https://agentapis.wattcrm.com/',
};
