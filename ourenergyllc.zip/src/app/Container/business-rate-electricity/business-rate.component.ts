import { Component, OnInit } from '@angular/core';
@Component({
    selector:'business-rates',
    templateUrl:'./business-rate.component.html',
    styleUrls:['./business-rate.component.scss']
})
export class BusinessRateComponent{
    
}