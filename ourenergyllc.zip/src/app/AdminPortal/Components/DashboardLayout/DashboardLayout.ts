import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'dashboardlayout',
    templateUrl: './DashboardLayout.html',
    styleUrls: ['../../Styles/DashboardLayout.scss']
})
export class DashboardLayout implements OnInit {
    constructor() { }
    ngOnInit() { }
}
