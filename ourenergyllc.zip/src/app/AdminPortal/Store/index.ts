import { DahsboardService } from './dashboard';
import { CustomersService } from './customers'

export {
    DahsboardService,
    CustomersService
}
